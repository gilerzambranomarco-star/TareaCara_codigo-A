"use strict";
/* Formulario: validacion y guardado de una tarea */
(function () {
  var form = document.getElementById("formulario");
  var fecha = document.getElementById("fecha");
  var desc = document.getElementById("descripcion");
  var contador = document.getElementById("contador");
  var exito = document.getElementById("exito");
  var MAX = 200;

  fecha.min = Almacen.hoyISO();

  desc.addEventListener("input", function () {
    contador.textContent = desc.value.length + " de " + MAX + " caracteres";
  });

  // Muestra u oculta el error de un campo; devuelve el campo si hay error
  function mostrar(id, mensaje) {
    var campo = document.getElementById(id);
    document.getElementById("e-" + id).textContent = mensaje;
    if (campo) {
      campo.classList.toggle("invalido", mensaje !== "");
      campo.setAttribute("aria-invalid", mensaje !== "" ? "true" : "false");
    }
    if (mensaje === "") { return null; }
    return campo || document.getElementById("p-alta");
  }

  function validar() {
    var errores = [];
    var titulo = document.getElementById("titulo").value.trim();
    var msgT = "";
    if (titulo === "") { msgT = "Escriba un título."; }
    else if (titulo.length < 3 || titulo.length > 60) { msgT = "El título debe tener entre 3 y 60 caracteres."; }
    errores.push(mostrar("titulo", msgT));

    errores.push(mostrar("materia", document.getElementById("materia").value === "" ? "Seleccione una materia." : ""));

    var msgF = "";
    if (fecha.value === "") { msgF = "Seleccione la fecha de entrega."; }
    else if (fecha.value < Almacen.hoyISO()) { msgF = "La fecha no puede ser anterior a hoy."; }
    errores.push(mostrar("fecha", msgF));

    var elegida = form.querySelector('input[name="prioridad"]:checked');
    errores.push(mostrar("prioridad", elegida ? "" : "Elija una prioridad."));

    return errores.filter(function (e) { return e !== null; });
  }

  form.addEventListener("submit", function (evento) {
    evento.preventDefault();
    exito.textContent = "";
    var errores = validar();
    if (errores.length > 0) {
      errores[0].focus();
      return;
    }
    Almacen.agregar({
      titulo: document.getElementById("titulo").value.trim(),
      materia: document.getElementById("materia").value,
      fecha: fecha.value,
      prioridad: form.querySelector('input[name="prioridad"]:checked').value,
      descripcion: desc.value.trim().slice(0, MAX)
    });
    form.reset();
    contador.textContent = "0 de " + MAX + " caracteres";
    exito.textContent = "Tarea guardada correctamente.";
    document.getElementById("titulo").focus();
  });
})();
